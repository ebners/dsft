## 1 Overview
This is a library composing some of the algorithms based on the novel mathematical foundation of discrete signal processing on set function. 
## 2 Installation
TODO: FINISH README
## References
